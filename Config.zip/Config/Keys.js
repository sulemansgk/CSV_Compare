module.exports = {
    mongoURI: 'mongodb://Alisons:alisons123@ds131932.mlab.com:31932/csv_compare',
    SecretOrKey: 'Alisons',
};